require("dotenv").config();
const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");

const LANGUAGES = require("./languages");
const app = express();
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const DEFAULT_BRAIN = (process.env.BRAIN || "claude").toLowerCase();
const CLAUDE_MODEL = process.env.CLAUDE_MODEL || "claude-sonnet-5-5";
const OLLAMA_URL = process.env.OLLAMA_URL || "http://localhost:11434";
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || "llama3.1";

const KNOWLEDGE_DIR = path.join(__dirname, "knowledge");
fs.mkdirSync(KNOWLEDGE_DIR, { recursive: true });

const SYSTEM_PROMPT =
  "You are Ultron AI, a helpful and friendly AI assistant. " +
  "Detect the language of the user's message automatically, including mixed languages and romanized text " +
  "(for example Tamil written in English letters), and reply in that same language and script. " +
  "If a reply language is set below, always use that language instead. " +
  "If knowledge notes are provided, prefer them and say when you are using them. " +
  "If you do not know something, say so honestly instead of guessing.";

app.get("/api/languages", (_req, res) => res.json({ languages: LANGUAGES }));

// ---------- Knowledge base (simple keyword search) ----------
function tokenize(text) {
  return (text.toLowerCase().match(/[\p{L}\p{N}]+/gu) || []).filter((w) => w.length > 2);
}

function loadChunks() {
  const chunks = [];
  for (const file of fs.readdirSync(KNOWLEDGE_DIR)) {
    if (!/\.(txt|md)$/i.test(file)) continue;
    const text = fs.readFileSync(path.join(KNOWLEDGE_DIR, file), "utf8");
    const parts = text.split(/\n\s*\n/).filter((p) => p.trim().length > 20);
    parts.forEach((p) => chunks.push({ file, text: p.trim(), tokens: new Set(tokenize(p)) }));
  }
  return chunks;
}

function searchKnowledge(query, limit = 4) {
  const q = tokenize(query);
  if (!q.length) return [];
  return loadChunks()
    .map((c) => ({ ...c, score: q.filter((t) => c.tokens.has(t)).length }))
    .filter((c) => c.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}

const upload = multer({
  storage: multer.diskStorage({
    destination: KNOWLEDGE_DIR,
    filename: (_req, file, cb) => cb(null, path.basename(file.originalname)),
  }),
  fileFilter: (_req, file, cb) => cb(null, /\.(txt|md)$/i.test(file.originalname)),
  limits: { fileSize: 2 * 1024 * 1024 },
});

app.post("/api/upload", upload.array("files", 10), (req, res) => {
  res.json({ saved: (req.files || []).map((f) => f.filename) });
});

app.get("/api/knowledge", (_req, res) => {
  res.json({ files: fs.readdirSync(KNOWLEDGE_DIR).filter((f) => /\.(txt|md)$/i.test(f)) });
});

// ---------- Brains ----------
async function askClaude(messages, system) {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) throw new Error("ANTHROPIC_API_KEY is missing in .env.");
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": key,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({ model: CLAUDE_MODEL, max_tokens: 1500, system, messages }),
  });
  const data = await r.json();
  if (!r.ok) throw new Error(data?.error?.message || "Claude API error");
  return data.content.map((b) => b.text || "").join("");
}

async function askOllama(messages, system) {
  const r = await fetch(`${OLLAMA_URL}/api/chat`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      model: OLLAMA_MODEL,
      stream: false,
      messages: [{ role: "system", content: system }, ...messages],
    }),
  });
  if (!r.ok) throw new Error("Ollama is not running. Start it with 'ollama serve' and make sure the model is downloaded.");
  const data = await r.json();
  return data.message?.content || "";
}

// ---------- Chat ----------
app.post("/api/chat", async (req, res) => {
  try {
    const { messages = [], brain = DEFAULT_BRAIN, language = "auto" } = req.body;
    const clean = messages
      .filter((m) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
      .slice(-20);
    if (!clean.length) return res.status(400).json({ error: "No message received." });

    const lastUser = [...clean].reverse().find((m) => m.role === "user")?.content || "";
    const hits = searchKnowledge(lastUser);
    const base = LANGUAGES.includes(language) ? SYSTEM_PROMPT + "\n\nReply language: " + language + "." : SYSTEM_PROMPT;
    const system = hits.length
      ? base +
        "\n\nKnowledge notes:\n" +
        hits.map((h, i) => `[${i + 1}] (${h.file}) ${h.text}`).join("\n\n")
      : base;

    const reply = brain === "ollama" ? await askOllama(clean, system) : await askClaude(clean, system);
    res.json({ reply, brain, sources: hits.map((h) => h.file) });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.listen(PORT, () => console.log(`Ultron AI ready: http://localhost:${PORT}  (brain: ${DEFAULT_BRAIN})`));
